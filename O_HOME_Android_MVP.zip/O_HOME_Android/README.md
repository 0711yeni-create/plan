# O.HOME Android MVP

폴더형 공부 관리 + OpenRouter AI 채팅을 결합한 초기 Android 프로젝트입니다.

## 현재 포함된 기능
- 어두운 보라색 테마의 홈 화면
- 기본 폴더 표시 및 폴더 추가
- 폴더 내부의 노트/할 일/자료/일정/캐릭터 구조 미리보기
- 플래너 할 일 추가 및 완료 체크
- OpenRouter API 키와 모델 ID 설정
- 실제 OpenRouter Chat Completions 요청
- 대화 화면에서 최근 메시지를 모델에 전달

## 아직 구현되지 않은 기능
- 노트와 할 일의 영구 저장/편집
- 하위 폴더, 사용자 제작 캐릭터
- 캐릭터별 대화 기록 분리 및 장기 기억
- 호감도, 관계 단계, 스토리 이벤트
- 캘린더/디데이/공부 시간 측정
- YouTube 사용량 모니터링
- 서버 중계 API 및 다중 기기 동기화

## Android Studio에서 실행
1. ZIP 압축을 풉니다.
2. Android Studio에서 `O_HOME_Android` 폴더를 엽니다.
3. Gradle Sync가 끝날 때까지 기다립니다.
4. Android SDK 35와 JDK 17을 설치/선택합니다.
5. 에뮬레이터 또는 Android 기기를 연결하고 Run을 누릅니다.

## OpenRouter 설정
앱 실행 후 `설정` 탭에서 OpenRouter API 키와 모델 ID를 입력합니다.
기본 모델 ID는 `openai/gpt-4o-mini`입니다. 계정에서 사용할 수 있는 모델 ID로 변경할 수 있습니다.

주의: 이 MVP는 API 키를 기기 로컬 SharedPreferences에 저장합니다. 개인 테스트용입니다. APK를 다른 사람에게 배포할 경우 앱에 API 키를 직접 저장하지 말고 서버 중계 방식을 구현하세요. API 키를 GitHub 저장소에 커밋하지 마세요.

## 빌드 검증
이 소스 ZIP은 생성되었지만, 이 환경에서 Gradle/Android SDK 빌드를 실행해 검증한 APK는 포함하지 않습니다. 첫 실행 시 Android Studio가 필요한 SDK와 Gradle 구성요소를 내려받아야 합니다.
