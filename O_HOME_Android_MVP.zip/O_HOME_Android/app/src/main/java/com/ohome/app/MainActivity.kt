package com.ohome.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Ink = Color(0xFF171522)
private val Panel = Color(0xFF242235)
private val Violet = Color(0xFFB9A4FF)
private val Muted = Color(0xFFB7B3C9)
private val Paper = Color(0xFFF4F0FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OHomeApp(applicationContext) }
    }
}

data class ChatLine(val role: String, val content: String)

@Composable
fun OHomeApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("ohome", Context.MODE_PRIVATE) }
    var page by remember { mutableStateOf("홈") }
    var folderName by remember { mutableStateOf("") }
    var folders by remember {
        mutableStateOf(prefs.getString("folders", "대수,영어,독서,개인 프로젝트")!!
            .split("|||").filter { it.isNotBlank() })
    }
    var selectedFolder by remember { mutableStateOf<String?>(null) }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "openai/gpt-4o-mini") ?: "openai/gpt-4o-mini") }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("API 키를 설정하면 AI 채팅을 사용할 수 있어요.") }
    var chat by remember { mutableStateOf(listOf(ChatLine("assistant", "안녕! 나는 O.HOME의 공부 파트너야. 오늘은 어떤 걸 같이 해볼까?"))) }
    var task by remember { mutableStateOf("") }
    var tasks by remember { mutableStateOf(listOf("오늘 공부할 과목 정하기", "복습할 개념 1개 확인하기")) }
    val scope = rememberCoroutineScope()

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet, onPrimary = Ink, background = Ink, surface = Panel,
            onSurface = Paper, onBackground = Paper, secondary = Muted
        )
    ) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Paper) {
                    listOf("홈", "폴더", "AI 채팅", "플래너", "설정").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item; selectedFolder = null },
                            icon = {
                                Icon(
                                    when (item) {
                                        "홈" -> Icons.Default.Home
                                        "폴더" -> Icons.Default.Folder
                                        "AI 채팅" -> Icons.Default.Chat
                                        "플래너" -> Icons.Default.CalendarMonth
                                        else -> Icons.Default.Settings
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Violet, selectedTextColor = Violet,
                                indicatorColor = Color(0xFF3A3156),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)
                    .background(Ink),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("O.HOME", color = Violet, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(
                            when (page) {
                                "홈" -> "나만의 공부 공간"
                                "폴더" -> selectedFolder ?: "폴더"
                                "AI 채팅" -> "캐릭터와 대화하기"
                                "플래너" -> "오늘의 작은 퀘스트"
                                else -> "앱 설정"
                            },
                            color = Paper, fontSize = 25.sp, fontWeight = FontWeight.Bold
                        )
                    }
                    Text("✦", color = Violet, fontSize = 32.sp)
                }

                when (page) {
                    "홈" -> {
                        CardBox {
                            Text("오늘의 목표", color = Muted, fontSize = 13.sp)
                            Text("완벽하게 말고, 조금이라도.", color = Paper, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                            Text("공부 기록과 캐릭터 반응을 한곳에 모아 보세요.", color = Muted)
                        }
                        Text("내 폴더", color = Paper, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(folders.take(4)) { name ->
                                FolderCard(name) { selectedFolder = name; page = "폴더" }
                            }
                        }
                        Button(onClick = { page = "AI 채팅" }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Chat, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("공부 파트너 만나기")
                        }
                    }
                    "폴더" -> {
                        if (selectedFolder == null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Field(folderName, { folderName = it }, "새 폴더 이름", Modifier.weight(1f))
                                Spacer(Modifier.width(8.dp))
                                Button(onClick = {
                                    val clean = folderName.trim()
                                    if (clean.isNotEmpty() && clean !in folders) {
                                        folders = folders + clean
                                        prefs.edit().putString("folders", folders.joinToString("|||")).apply()
                                        folderName = ""
                                    }
                                }) { Icon(Icons.Default.Add, contentDescription = "추가") }
                            }
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(folders) { name -> FolderCard(name) { selectedFolder = name } }
                            }
                        } else {
                            TextButton(onClick = { selectedFolder = null }) { Text("← 폴더 목록") }
                            CardBox {
                                Text(selectedFolder!!, color = Violet, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("이 폴더에 연결할 공간", color = Muted)
                                ListRow("노트", "개념 정리와 오답 메모")
                                ListRow("할 일", "학습 과제와 체크리스트")
                                ListRow("자료", "교재와 참고 자료")
                                ListRow("일정", "시험일과 복습 계획")
                                ListRow("담당 캐릭터", "AI 공부 파트너")
                            }
                            Button(onClick = { page = "AI 채팅" }, modifier = Modifier.fillMaxWidth()) {
                                Text("이 폴더 공부를 AI와 이야기하기")
                            }
                        }
                    }
                    "AI 채팅" -> {
                        CardBox {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(42.dp).background(Color(0xFF40365F), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                                    Text("✦", color = Violet, fontSize = 24.sp)
                                }
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text("공부 파트너", color = Paper, fontWeight = FontWeight.Bold)
                                    Text("차분하고 현실적인 응원", color = Muted, fontSize = 12.sp)
                                }
                            }
                        }
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(chat) { line ->
                                Column(
                                    Modifier.fillMaxWidth(),
                                    horizontalAlignment = if (line.role == "user") Alignment.End else Alignment.Start
                                ) {
                                    Box(
                                        Modifier.widthIn(max = 310.dp)
                                            .background(if (line.role == "user") Color(0xFF554778) else Panel, RoundedCornerShape(16.dp))
                                            .padding(12.dp)
                                    ) { Text(line.content, color = Paper) }
                                }
                            }
                        }
                        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Field(draft, { draft = it }, "메시지 입력...", Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            IconButton(onClick = {
                                val msg = draft.trim()
                                if (msg.isNotEmpty() && !busy) {
                                    chat = chat + ChatLine("user", msg)
                                    draft = ""
                                    busy = true
                                    scope.launch {
                                        val result = requestOpenRouter(apiKey, model, chat)
                                        chat = chat + ChatLine("assistant", result)
                                        status = if (result.startsWith("연결 오류:")) result else "답변을 받았어요."
                                        busy = false
                                    }
                                }
                            }, enabled = !busy) { Icon(Icons.Default.Send, contentDescription = "전송", tint = Violet) }
                        }
                        Text(status, color = Muted, fontSize = 11.sp)
                    }
                    "플래너" -> {
                        CardBox {
                            Text("오늘", color = Violet, fontWeight = FontWeight.Bold)
                            Text("작게 시작해서 완료 표시하기", color = Paper, fontSize = 18.sp)
                            Text("퀘스트를 완료하면 스스로에게 경험치 +10을 준다고 생각해 봐요.", color = Muted)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Field(task, { task = it }, "할 일 추가", Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = {
                                if (task.isNotBlank()) { tasks = tasks + task.trim(); task = "" }
                            }) { Icon(Icons.Default.Add, contentDescription = "추가") }
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(tasks) { item ->
                                var checked by remember(item) { mutableStateOf(false) }
                                CardBox {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked, { checked = it })
                                        Text(item, color = if (checked) Muted else Paper, modifier = Modifier.weight(1f))
                                        Text(if (checked) "+10 XP" else "퀘스트", color = Violet, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Text("AI 연결", color = Violet, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("OpenRouter API 키는 기기 내부에 저장됩니다. 이 방식은 개인 테스트용이며, 앱을 공개 배포할 때는 서버 중계 방식을 사용하세요.", color = Muted, fontSize = 13.sp)
                        Text("API 키", color = Paper, fontWeight = FontWeight.SemiBold)
                        Field(apiKey, { apiKey = it; prefs.edit().putString("api_key", it).apply() }, "sk-or-...", Modifier.fillMaxWidth())
                        Text("모델 ID", color = Paper, fontWeight = FontWeight.SemiBold)
                        Field(model, { model = it; prefs.edit().putString("model", it).apply() }, "openai/gpt-4o-mini", Modifier.fillMaxWidth())
                        Button(onClick = {
                            scope.launch {
                                busy = true
                                status = requestOpenRouter(apiKey, model, listOf(ChatLine("user", "이 연결 테스트에 짧게 응답해 줘.")))
                                busy = false
                            }
                        }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("AI 연결 테스트") }
                        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                        Text(status, color = Muted, fontSize = 12.sp)
                        OutlinedButton(onClick = {
                            apiKey = ""; prefs.edit().remove("api_key").apply()
                            status = "저장된 API 키를 삭제했어요."
                        }, modifier = Modifier.fillMaxWidth()) { Text("API 키 삭제") }
                        Divider(color = Panel)
                        Text("현재 버전은 초기 MVP입니다. 폴더와 설정은 기기에 저장되며, 노트 동기화·장기 기억·관계 이벤트·사용 시간 모니터링은 아직 구현되지 않았습니다.", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(4.dp))
            }
        }
    }
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
private fun FolderCard(name: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(Color(0xFF39314F), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Folder, contentDescription = null, tint = Violet)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = Paper, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text("노트 · 할 일 · 자료 · 캐릭터", color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Muted)
        }
    }
}

@Composable
private fun ListRow(title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Circle, contentDescription = null, tint = Violet, modifier = Modifier.size(8.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, color = Paper, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun Field(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier) {
    Box(
        modifier.background(Panel, RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 13.dp)
    ) {
        if (value.isEmpty()) Text(hint, color = Muted, fontSize = 14.sp)
        BasicTextField(
            value = value, onValueChange = onChange,
            modifier = Modifier.fillMaxWidth(),
            textStyle = androidx.compose.ui.text.TextStyle(color = Paper, fontSize = 14.sp),
            singleLine = true
        )
    }
}

private suspend fun requestOpenRouter(apiKey: String, model: String, messages: List<ChatLine>): String =
    withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext "연결 오류: 설정에서 OpenRouter API 키를 먼저 입력해 주세요."
        if (model.isBlank()) return@withContext "연결 오류: 모델 ID를 입력해 주세요."
        var connection: HttpURLConnection? = null
        try {
            connection = (URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 45000
                doOutput = true
                setRequestProperty("Authorization", "Bearer $apiKey")
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("HTTP-Referer", "https://ohome.local")
                setRequestProperty("X-Title", "O.HOME")
            }
            val messageArray = JSONArray()
            messageArray.put(JSONObject().put("role", "system").put("content",
                "너는 O.HOME의 공부 파트너다. 친근하고 자연스러운 한국어로 답하고, 공부 질문은 단계별로 설명한다."))
            messages.takeLast(24).forEach {
                messageArray.put(JSONObject().put("role", it.role).put("content", it.content))
            }
            val body = JSONObject().put("model", model).put("messages", messageArray).toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                val detail = try { JSONObject(response).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                return@withContext "연결 오류: HTTP $code${if (!detail.isNullOrBlank()) " · $detail" else ""}"
            }
            val root = JSONObject(response)
            root.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
                .ifBlank { "응답은 받았지만 내용이 비어 있어요." }
        } catch (e: Exception) {
            "연결 오류: ${e.message ?: "네트워크 또는 API 설정을 확인해 주세요."}"
        } finally {
            connection?.disconnect()
        }
    }
