package com.ohome.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import java.time.LocalDate

/** User-started foreground monitor. Android Usage Access must be enabled first. */
class UsageMonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("ohome", Context.MODE_PRIVATE) }
    private val channelId = "ohome_usage_monitor"
    private val serviceNotificationId = 7201
    private val poll = object : Runnable {
        override fun run() {
            checkUsageAndNudge()
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(serviceNotificationId, buildServiceNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            handler.removeCallbacks(poll)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        handler.removeCallbacks(poll)
        handler.post(poll)
        return START_STICKY
    }

    private fun checkUsageAndNudge() {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        val mode = ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        if (mode != android.app.AppOpsManager.MODE_ALLOWED) return
        val targetPackages = prefs.getString("target_apps", "com.google.android.youtube,com.instagram.android,com.zhiliaoapp.musically")
            .orEmpty().split(",").map { it.trim() }.filter { it.isNotBlank() }
        val threshold = prefs.getInt("usage_threshold", 15) * 60_000L
        val now = System.currentTimeMillis()
        val start = LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        val usage = (getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager)
            .queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, now)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        targetPackages.forEach { pkg ->
            val total = usage.filter { it.packageName == pkg }.sumOf { it.totalTimeInForeground }
            val key = "nudge_${LocalDate.now()}_$pkg"
            if (total >= threshold && !prefs.getBoolean(key, false)) {
                val message = prefs.getString("nudge_text", "잠깐 쉬었으니 이제 공부로 돌아올 시간!") ?: "잠깐 쉬었으니 이제 공부로 돌아올 시간!"
                val openApp = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val notification = NotificationCompat.Builder(this, channelId)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("O.HOME · $pkg 사용 시간이 길어졌어요")
                    .setContentText(message)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                    .setContentIntent(openApp)
                    .setAutoCancel(true)
                    .build()
                manager.notify((pkg.hashCode() and 0x7fffffff) % 100000 + 100, notification)
                prefs.edit().putBoolean(key, true).apply()
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "공부 복귀 알림", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "지정한 앱의 일일 사용 시간이 설정값을 넘으면 캐릭터 알림을 보냅니다."
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildServiceNotification(): Notification {
        val stopIntent = PendingIntent.getService(this, 1, Intent(this, UsageMonitorService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("O.HOME 딴짓 감지 실행 중")
            .setContentText("지정 앱의 사용 시간을 확인하고 있어요.")
            .addAction(0, "감지 중지", stopIntent)
            .setOngoing(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(poll)
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.ohome.app.STOP_USAGE_MONITOR"
    }
}
