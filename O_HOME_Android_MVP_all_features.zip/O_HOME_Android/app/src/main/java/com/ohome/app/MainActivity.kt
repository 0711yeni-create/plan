package com.ohome.app

import android.content.Context
import android.content.Intent
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.provider.Settings
import android.net.Uri
import android.os.Process
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Ink = Color(0xFF171522)
private val Panel = Color(0xFF242235)
private val Violet = Color(0xFFB9A4FF)
private val Muted = Color(0xFFB7B3C9)
private val Paper = Color(0xFFF4F0FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OHomeApp(applicationContext) }
    }
}

data class ChatLine(val role: String, val content: String)

@Composable
fun OHomeApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("ohome", Context.MODE_PRIVATE) }
    var page by remember { mutableStateOf("홈") }
    var characterName by remember { mutableStateOf(prefs.getString("character_name", "서윤") ?: "서윤") }
    var characterPersonality by remember { mutableStateOf(prefs.getString("character_personality", "까칠하지만 다정함") ?: "까칠하지만 다정함") }
    var characterBackground by remember { mutableStateOf(prefs.getString("character_background", "같은 학교에 다니는 공부 라이벌. 평소에는 툴툴거리지만 내가 힘들 때는 은근히 챙겨 준다.") ?: "") }
    var relationshipSpeed by remember { mutableStateOf(prefs.getString("relationship_speed", "천천히 발전") ?: "천천히 발전") }
    var relationshipType by remember { mutableStateOf(prefs.getString("relationship_type", "연애 가능") ?: "연애 가능") }
    var affection by remember { mutableIntStateOf(prefs.getInt("affection", 0)) }
    var relationshipStage by remember { mutableStateOf(prefs.getString("relationship_stage", "공부 파트너") ?: "공부 파트너") }
    var characterList by remember { mutableStateOf(prefs.getString("characters", "서윤|까칠하지만 다정함|같은 학교의 공부 라이벌|연애 가능|천천히 발전|||고해준|엄격하고 현실적임|공부를 미루면 짧게 지적하는 개인 비서|친구 전용|보통")!!.split("|||").filter { it.isNotBlank() }) }
    var newCharacter by remember { mutableStateOf("") }
    var newCharacterPersonality by remember { mutableStateOf("다정하고 헌신적임") }
    var folderIcon by remember { mutableStateOf(prefs.getString("folder_icon", "📁") ?: "📁") }
    var folderColor by remember { mutableStateOf(prefs.getString("folder_color", "보라") ?: "보라") }
    var folderCharacter by remember { mutableStateOf(prefs.getString("folder_character", "") ?: "") }
    var bookTitle by remember { mutableStateOf(prefs.getString("book_title", "") ?: "") }
    var bookProgress by remember { mutableStateOf(prefs.getInt("book_progress", 0)) }
    var bookNotes by remember { mutableStateOf(prefs.getString("book_notes", "") ?: "") }
    var calendarDate by remember { mutableStateOf(LocalDate.now().toString()) }
    var calendarTitle by remember { mutableStateOf("") }
    var calendarItems by remember { mutableStateOf(prefs.getString("calendar_items", "")!!.split("|||").filter { it.isNotBlank() }) }
    var recordText by remember { mutableStateOf(prefs.getString("record_text", "") ?: "") }
    var completedTasks by remember { mutableStateOf(prefs.getString("completed_tasks", "")!!.split("|||").filter { it.isNotBlank() }.toSet()) }
    var targetApps by remember { mutableStateOf(prefs.getString("target_apps", "com.google.android.youtube,com.instagram.android,com.zhiliaoapp.musically") ?: "com.google.android.youtube,com.instagram.android,com.zhiliaoapp.musically") }
    var usageThreshold by remember { mutableIntStateOf(prefs.getInt("usage_threshold", 15)) }
    var nudgeText by remember { mutableStateOf(prefs.getString("nudge_text", "유튜브가 네 수학 문제까지 풀어주진 않거든. 이제 그만 보고 공부해.") ?: "") }
    var focusMinutes by remember { mutableIntStateOf(25) }
    var focusRemainingSeconds by remember { mutableIntStateOf(0) }
    var focusTimerRunning by remember { mutableStateOf(false) }
    var focusSessions by remember { mutableIntStateOf(prefs.getInt("focus_sessions", 0)) }
    var streakDays by remember { mutableIntStateOf(prefs.getInt("streak_days", 0)) }
    LaunchedEffect(focusTimerRunning, focusRemainingSeconds) {
        if (focusTimerRunning && focusRemainingSeconds > 0) {
            kotlinx.coroutines.delay(1000)
            focusRemainingSeconds -= 1
        } else if (focusTimerRunning && focusRemainingSeconds == 0) {
            focusTimerRunning = false
            focusSessions += 1
            recordText = (recordText + "\n${LocalDate.now()} · 집중 세션 ${focusMinutes}분 완료").trim()
            streakDays = calculateStreak(recordText)
            prefs.edit().putInt("focus_sessions", focusSessions).putInt("streak_days", streakDays).putString("record_text", recordText).apply()
        }
    }
    var monitoringStatus by remember { mutableStateOf("사용 기록 접근 권한을 확인해 주세요.") }
    var folderName by remember { mutableStateOf("") }
    var folders by remember {
        mutableStateOf(prefs.getString("folders", "대수|||영어|||독서|||개인 프로젝트")!!
            .split("|||").filter { it.isNotBlank() })
    }
    var selectedFolder by remember { mutableStateOf<String?>(null) }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "openai/gpt-4o-mini") ?: "openai/gpt-4o-mini") }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("API 키를 설정하면 AI 채팅을 사용할 수 있어요.") }
    var chat by remember { mutableStateOf(listOf(ChatLine("assistant", "안녕! 나는 O.HOME의 공부 파트너야. 오늘은 어떤 걸 같이 해볼까?"))) }
    var task by remember { mutableStateOf("") }
    var tasks by remember { mutableStateOf(prefs.getString("tasks", "오늘 공부할 과목 정하기|||복습할 개념 1개 확인하기")!!.split("|||").filter { it.isNotBlank() }) }
    val scope = rememberCoroutineScope()

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet, onPrimary = Ink, background = Ink, surface = Panel,
            onSurface = Paper, onBackground = Paper, secondary = Muted
        )
    ) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Paper) {
                    listOf("홈", "폴더", "캐릭터", "AI 채팅", "캘린더", "퀘스트", "기록", "설정").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item; selectedFolder = null },
                            icon = {
                                Icon(
                                    when (item) {
                                        "홈" -> Icons.Default.Home
                                        "폴더" -> Icons.Default.Folder
                                        "캐릭터" -> Icons.Default.Face
                                        "AI 채팅" -> Icons.Default.Chat
                                        "캘린더" -> Icons.Default.CalendarMonth
                                        "퀘스트" -> Icons.Default.CheckCircle
                                        "기록" -> Icons.Default.AutoStories
                                        else -> Icons.Default.Settings
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Violet, selectedTextColor = Violet,
                                indicatorColor = Color(0xFF3A3156),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)
                    .background(Ink),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("O.HOME", color = Violet, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(
                            when (page) {
                                "홈" -> "나만의 공부 공간"
                                "폴더" -> selectedFolder ?: "폴더"
                                "캐릭터" -> "나만의 캐릭터 만들기"
                                "AI 채팅" -> "$characterName와 대화하기"
                                "캘린더" -> "일정과 디데이"
                                "퀘스트" -> "공부를 작은 미션으로"
                                "기록" -> "독서와 공부 기록"
                                else -> "AI · 알림 · 딴짓 감지 설정"
                            },
                            color = Paper, fontSize = 25.sp, fontWeight = FontWeight.Bold
                        )
                    }
                    Text("✦", color = Violet, fontSize = 32.sp)
                }

                when (page) {
                    "홈" -> {
                        CardBox {
                            Text("오늘의 목표", color = Muted, fontSize = 13.sp)
                            Text("완벽하게 말고, 조금이라도.", color = Paper, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                            Text("공부 기록과 캐릭터 반응을 한곳에 모아 보세요.", color = Muted)
                            Text("오늘 날짜 · ${LocalDate.now().format(DateTimeFormatter.ofPattern("M월 d일 · E요일", java.util.Locale.KOREAN))}", color = Violet)
                            Text("연속 공부 $streakDays일 · 집중 세션 $focusSessions회", color = Muted)
                        }
                        CardBox {
                            Text("오늘의 한마디 · $characterName", color = Violet, fontWeight = FontWeight.Bold)
                            Text(nudgeText, color = Paper)
                            Button(onClick = { page = "퀘스트" }, modifier = Modifier.fillMaxWidth()) { Text("오늘의 퀘스트 확인") }
                        }
                        Text("내 폴더", color = Paper, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(folders.take(4)) { name ->
                                FolderCard(name, prefs.getString("folder_icon_$name", "📁") ?: "📁", prefs.getString("folder_color_$name", "보라") ?: "보라") { selectedFolder = name; folderIcon = prefs.getString("folder_icon_$name", "📁") ?: "📁"; folderColor = prefs.getString("folder_color_$name", "보라") ?: "보라"; folderCharacter = prefs.getString("folder_character_$name", "") ?: ""; page = "폴더" }
                            }
                        }
                        Button(onClick = { page = "AI 채팅" }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Chat, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("공부 파트너 만나기")
                        }
                    }
                    "폴더" -> {
                        if (selectedFolder == null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Field(folderName, { folderName = it }, "새 폴더 이름", Modifier.weight(1f))
                                Spacer(Modifier.width(8.dp))
                                Button(onClick = {
                                    val clean = folderName.trim()
                                    if (clean.isNotEmpty() && folders.none { it.substringAfterLast("/") == clean && !it.contains("/") }) {
                                        folders = folders + clean
                                        prefs.edit().putString("folders", folders.joinToString("||| ").replace("||| ", "|||" )).apply()
                                        folderName = ""
                                    }
                                }) { Icon(Icons.Default.Add, contentDescription = "추가") }
                            }
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(folders.filter { !it.contains("/") }) { path ->
                                    FolderCard(path, prefs.getString("folder_icon_$path", "📁") ?: "📁", prefs.getString("folder_color_$path", "보라") ?: "보라") { selectedFolder = path; folderIcon = prefs.getString("folder_icon_$path", "📁") ?: "📁"; folderColor = prefs.getString("folder_color_$path", "보라") ?: "보라"; folderCharacter = prefs.getString("folder_character_$path", "") ?: "" }
                                }
                            }
                        } else {
                            val currentPath = selectedFolder!!
                            val children = folders.filter { it.startsWith("$currentPath/") && it.removePrefix("$currentPath/").isNotBlank() && !it.removePrefix("$currentPath/").contains("/") }
                            var subfolderName by remember(currentPath) { mutableStateOf("") }
                            var renamedFolder by remember(currentPath) { mutableStateOf(currentPath.substringAfterLast("/")) }
                            TextButton(onClick = { selectedFolder = currentPath.substringBeforeLast("/", "").ifBlank { null } }) { Text("← 상위 폴더") }
                            CardBox {
                                Text("📁 $currentPath", color = Violet, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("하위 폴더를 만들고 공부 자료와 기록을 정리하세요.", color = Muted)
                                ListRow("노트", "개념 정리와 오답 메모")
                                ListRow("퀘스트", "이 폴더에 연결할 학습 과제")
                                ListRow("자료", "교재와 참고 자료")
                                ListRow("일정", "시험일과 복습 계획")
                                ListRow("담당 캐릭터", "폴더 전용 AI 공부 파트너")
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Field(subfolderName, { subfolderName = it }, "하위 폴더 이름", Modifier.weight(1f))
                                Spacer(Modifier.width(8.dp))
                                Button(onClick = {
                                    val clean = subfolderName.trim()
                                    val fullPath = "$currentPath/$clean"
                                    if (clean.isNotEmpty() && fullPath !in folders) {
                                        folders = folders + fullPath
                                        prefs.edit().putString("folders", folders.joinToString("|||" )).apply()
                                        subfolderName = ""
                                    }
                                }) { Icon(Icons.Default.CreateNewFolder, contentDescription = "하위 폴더 추가") }
                            }
                            if (children.isNotEmpty()) {
                                Text("하위 폴더", color = Paper, fontWeight = FontWeight.Bold)
                                children.forEach { child -> FolderCard(child.substringAfterLast("/"), prefs.getString("folder_icon_$child", "📁") ?: "📁", prefs.getString("folder_color_$child", "보라") ?: "보라") { selectedFolder = child; folderIcon = prefs.getString("folder_icon_$child", "📁") ?: "📁"; folderColor = prefs.getString("folder_color_$child", "보라") ?: "보라"; folderCharacter = prefs.getString("folder_character_$child", "") ?: "" } }
                            }
                            Button(onClick = { page = "AI 채팅" }, modifier = Modifier.fillMaxWidth()) {
                                Text("이 폴더 공부를 AI와 이야기하기")
                            }
                        }
                    }
                    "캐릭터" -> {
                        CardBox {
                            Text("캐릭터 프로필 미리보기", color = Violet, fontWeight = FontWeight.Bold)
                            Text(characterName, color = Paper, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            Text("$characterPersonality · $relationshipSpeed", color = Muted)
                            Text(characterBackground, color = Paper)
                            Text("관계: $relationshipStage  ·  친밀도 $affection", color = Violet, fontWeight = FontWeight.SemiBold)
                            LinearProgressIndicator(progress = { (affection % 100) / 100f }, modifier = Modifier.fillMaxWidth())
                            Text("공부 퀘스트와 대화로 친밀도가 쌓여요. 공부를 못 했다고 친밀도가 떨어지지는 않아요.", color = Muted, fontSize = 12.sp)
                        }
                        Text("캐릭터 이름", color = Paper, fontWeight = FontWeight.SemiBold)
                        Field(characterName, { characterName = it; prefs.edit().putString("character_name", it).apply() }, "캐릭터 이름", Modifier.fillMaxWidth())
                        Text("성격", color = Paper, fontWeight = FontWeight.SemiBold)
                        var personalityMenu by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick = { personalityMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(characterPersonality) }
                            DropdownMenu(expanded = personalityMenu, onDismissRequest = { personalityMenu = false }) {
                                listOf("까칠하지만 다정함", "무뚝뚝하고 냉정함", "장난스럽고 능글맞음", "다정하고 헌신적임", "직접 설정").forEach { option ->
                                    DropdownMenuItem(text = { Text(option) }, onClick = { characterPersonality = option; prefs.edit().putString("character_personality", option).apply(); personalityMenu = false })
                                }
                            }
                        }
                        Text("관계 발전 속도", color = Paper, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("천천히 발전", "보통", "빠르게 발전").forEach { option ->
                                FilterChip(selected = relationshipSpeed == option, onClick = { relationshipSpeed = option; prefs.edit().putString("relationship_speed", option).apply() }, label = { Text(option, fontSize = 11.sp) })
                            }
                        }
                        Text("관계 설정", color = Paper, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("연애 가능", "친구 전용", "공부 파트너 전용").forEach { option ->
                                FilterChip(selected = relationshipType == option, onClick = { relationshipType = option; prefs.edit().putString("relationship_type", option).apply(); if (option != "연애 가능" && relationshipStage == "연인") relationshipStage = "친구" }, label = { Text(option, fontSize = 10.sp) })
                            }
                        }
                        Text("캐릭터 배경과 관계", color = Paper, fontWeight = FontWeight.SemiBold)
                        Field(characterBackground, { characterBackground = it; prefs.edit().putString("character_background", it).apply() }, "배경 설정", Modifier.fillMaxWidth())
                        Divider(color = Panel)
                        Text("캐릭터 보관함", color = Paper, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("과목별·책별로 여러 캐릭터를 만들어 전환할 수 있어요.", color = Muted, fontSize = 12.sp)
                        characterList.forEach { saved ->
                            val parts = saved.split("|")
                            CardBox {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(parts.getOrElse(0) { "캐릭터" }, color = Paper, fontWeight = FontWeight.Bold)
                                        Text(parts.getOrElse(1) { "다정함" }, color = Muted, fontSize = 12.sp)
                                        Text(parts.getOrElse(2) { "" }, color = Muted, fontSize = 11.sp)
                                    }
                                    Button(onClick = {
                                        characterName = parts.getOrElse(0) { "서윤" }; characterPersonality = parts.getOrElse(1) { "다정함" }; characterBackground = parts.getOrElse(2) { "" }; relationshipType = parts.getOrElse(3) { "연애 가능" }; relationshipSpeed = parts.getOrElse(4) { "보통" }
                                        prefs.edit().putString("character_name", characterName).putString("character_personality", characterPersonality).putString("character_background", characterBackground).putString("relationship_type", relationshipType).putString("relationship_speed", relationshipSpeed).apply()
                                    }) { Text("선택") }
                                }
                            }
                        }
                        Field(newCharacter, { newCharacter = it }, "새 캐릭터 이름", Modifier.fillMaxWidth())
                        Field(newCharacterPersonality, { newCharacterPersonality = it }, "성격을 직접 입력", Modifier.fillMaxWidth())
                        Button(onClick = {
                            if (newCharacter.isNotBlank()) {
                                val item = "${newCharacter.trim()}|${newCharacterPersonality.trim()}|직접 만든 오리지널 캐릭터|연애 가능|천천히 발전"
                                characterList = characterList + item
                                prefs.edit().putString("characters", characterList.joinToString("|||" )).apply()
                                characterName = newCharacter.trim(); characterPersonality = newCharacterPersonality.trim(); characterBackground = "직접 만든 오리지널 캐릭터"
                                prefs.edit().putString("character_name", characterName).putString("character_personality", characterPersonality).putString("character_background", characterBackground).apply()
                                newCharacter = ""
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("캐릭터 생성 및 저장") }
                        Button(onClick = { page = "AI 채팅" }, modifier = Modifier.fillMaxWidth()) { Text("$characterName와 대화하기") }
                    }
                    "AI 채팅" -> {
                        CardBox {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(42.dp).background(Color(0xFF40365F), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                                    Text("✦", color = Violet, fontSize = 24.sp)
                                }
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(characterName, color = Paper, fontWeight = FontWeight.Bold)
                                    Text("$characterPersonality · $relationshipStage", color = Muted, fontSize = 12.sp)
                                }
                            }
                        }
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(chat) { line ->
                                Column(
                                    Modifier.fillMaxWidth(),
                                    horizontalAlignment = if (line.role == "user") Alignment.End else Alignment.Start
                                ) {
                                    Box(
                                        Modifier.widthIn(max = 310.dp)
                                            .background(if (line.role == "user") Color(0xFF554778) else Panel, RoundedCornerShape(16.dp))
                                            .padding(12.dp)
                                    ) { Text(line.content, color = Paper) }
                                }
                            }
                        }
                        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Field(draft, { draft = it }, "메시지 입력...", Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            IconButton(onClick = {
                                val msg = draft.trim()
                                if (msg.isNotEmpty() && !busy) {
                                    chat = chat + ChatLine("user", msg)
                                    draft = ""
                                    busy = true
                                    scope.launch {
                                        val result = requestOpenRouter(apiKey, model, chat, characterName, characterPersonality, characterBackground + "\n현재 공부 폴더: ${selectedFolder ?: "공부방"}. 이 폴더의 공부 목표와 기록을 우선 참고해 대화한다.", relationshipStage, relationshipType, relationshipSpeed)
                                        chat = chat + ChatLine("assistant", result)
                                        status = if (result.startsWith("연결 오류:")) result else "답변을 받았어요."
                                        busy = false
                                    }
                                }
                            }, enabled = !busy) { Icon(Icons.Default.Send, contentDescription = "전송", tint = Violet) }
                        }
                        Text(status, color = Muted, fontSize = 11.sp)
                    }
                    "캘린더" -> {
                        CardBox {
                            Text("일정 등록", color = Violet, fontWeight = FontWeight.Bold)
                            Field(calendarDate, { calendarDate = it }, "날짜 YYYY-MM-DD", Modifier.fillMaxWidth())
                            Field(calendarTitle, { calendarTitle = it }, "시험 · 마감 · 독서 목표", Modifier.fillMaxWidth())
                            Button(onClick = {
                                if (calendarTitle.isNotBlank() && runCatching { LocalDate.parse(calendarDate) }.isSuccess) {
                                    calendarItems = calendarItems + "$calendarDate|${calendarTitle.trim()}"
                                    prefs.edit().putString("calendar_items", calendarItems.joinToString("|||" )).apply(); calendarTitle = ""
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("일정 추가") }
                        }
                        Text("다가오는 일정", color = Paper, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        calendarItems.sorted().forEach { entry ->
                            val parts = entry.split("|", limit = 2)
                            CardBox {
                                Text(parts.getOrElse(0) { "날짜 미정" }, color = Violet, fontWeight = FontWeight.Bold)
                                Text(parts.getOrElse(1) { entry }, color = Paper)
                                val days = runCatching { java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(parts[0])).toInt() }.getOrNull()
                                if (days != null) Text(if (days >= 0) "D-$days" else "${-days}일 지남", color = Muted, fontSize = 12.sp)
                                TextButton(onClick = { calendarItems = calendarItems.filterNot { it == entry }; prefs.edit().putString("calendar_items", calendarItems.joinToString("|||" )).apply() }) { Text("삭제") }
                            }
                        }
                        if (calendarItems.isEmpty()) Text("등록된 일정이 없어요. 시험일이나 책 완독 목표를 추가해 보세요.", color = Muted)
                    }
                    "퀘스트" -> {
                        CardBox {
                            Text("오늘의 퀘스트", color = Violet, fontWeight = FontWeight.Bold)
                            Text("완료한 퀘스트는 XP와 친밀도로 이어져요. 미완료 페널티는 없어요.", color = Muted)
                            Text("${tasks.count { it in completedTasks }} / ${tasks.size} 완료", color = Paper, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Field(task, { task = it }, "직접 퀘스트 추가", Modifier.weight(1f))
                            Button(onClick = { if (task.isNotBlank()) { tasks = tasks + task.trim(); task = ""; prefs.edit().putString("tasks", tasks.joinToString("|||" )).apply() } }) { Icon(Icons.Default.Add, contentDescription = "추가") }
                        }
                        Button(onClick = {
                            if (apiKey.isBlank()) {
                                val suggestion = if (calendarItems.any { it.contains("시험") }) "시험 범위 15분 복습하기" else "가장 막히는 문제 하나 풀어 보기"
                                if (suggestion !in tasks) { tasks = tasks + suggestion; prefs.edit().putString("tasks", tasks.joinToString("|||" )).apply() }
                                status = "API 키가 없어 기본 퀘스트를 제안했어요. 설정에서 AI를 연결하면 맞춤 제안을 받을 수 있어요."
                            } else {
                                scope.launch {
                                    busy = true
                                    val suggestion = requestOpenRouter(apiKey, model, listOf(ChatLine("user", "현재 날짜는 ${LocalDate.now()}이고 예정 일정은 ${calendarItems.joinToString() }, 현재 폴더는 ${selectedFolder ?: "공부방"}이야. 부담 없는 공부 퀘스트를 정확히 한 줄로 제안해 줘. 설명이나 번호 없이 퀘스트만 출력해.")), characterName, characterPersonality, characterBackground, relationshipStage, relationshipType, relationshipSpeed).trim().lines().firstOrNull().orEmpty()
                                    if (suggestion.isNotBlank() && !suggestion.startsWith("연결 오류:")) { tasks = tasks + suggestion; prefs.edit().putString("tasks", tasks.joinToString("|||" )).apply(); status = "AI 퀘스트를 추가했어요." } else status = suggestion.ifBlank { "퀘스트 생성에 실패했어요." }
                                    busy = false
                                }
                            }
                        }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("AI 퀘스트 제안 받기") }
                        tasks.forEach { item ->
                            val checked = item in completedTasks
                            CardBox {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked, onCheckedChange = { value ->
                                        completedTasks = if (value) completedTasks + item else completedTasks - item
                                        prefs.edit().putString("completed_tasks", completedTasks.joinToString("|||" )).apply()
                                        if (value && !checked) {
                                            affection += 5; prefs.edit().putInt("affection", affection).apply()
                                            val threshold = when (relationshipSpeed) { "빠르게 발전" -> 20; "보통" -> 35; else -> 50 }
                                            relationshipStage = when { affection >= threshold * 3 && relationshipType == "연애 가능" -> "연인"; affection >= threshold * 2 -> "썸"; affection >= threshold -> "친구"; else -> "공부 파트너" }
                                            prefs.edit().putString("relationship_stage", relationshipStage).apply()
                                        }
                                    })
                                    Text(item, color = if (checked) Muted else Paper, modifier = Modifier.weight(1f))
                                    Text(if (checked) "+10 XP" else "퀘스트", color = Violet, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    "기록" -> {
                        CardBox {
                            Text("독서 기록", color = Violet, fontWeight = FontWeight.Bold)
                            Field(bookTitle, { bookTitle = it; prefs.edit().putString("book_title", it).apply() }, "책 제목", Modifier.fillMaxWidth())
                            Text("읽은 진도: $bookProgress%", color = Paper)
                            Slider(value = bookProgress.toFloat(), onValueChange = { bookProgress = it.toInt(); prefs.edit().putInt("book_progress", bookProgress).apply() }, valueRange = 0f..100f, steps = 99)
                            Field(bookNotes, { bookNotes = it; prefs.edit().putString("book_notes", it).apply() }, "인용 메모 · 감상 · 오답 기록", Modifier.fillMaxWidth())
                            Button(onClick = { recordText = (recordText + "\n${LocalDate.now()} · ${bookTitle.ifBlank { "독서/공부 기록" }} · 진도 $bookProgress%\n$bookNotes").trim(); prefs.edit().putString("record_text", recordText).apply() }, modifier = Modifier.fillMaxWidth()) { Text("오늘 기록 저장") }
                        }
                        CardBox {
                            Text("집중 세션", color = Violet, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(15, 25, 45).forEach { m -> FilterChip(selected = focusMinutes == m, onClick = { focusMinutes = m }, label = { Text("$m분") }) } }
                            Text(if (focusTimerRunning) "남은 시간 ${focusRemainingSeconds / 60}:${(focusRemainingSeconds % 60).toString().padStart(2, '0')}" else "집중할 시간을 고르고 시작하세요.", color = Paper, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { if (!focusTimerRunning) { if (focusRemainingSeconds <= 0) focusRemainingSeconds = focusMinutes * 60; focusTimerRunning = true } }, enabled = !focusTimerRunning, modifier = Modifier.weight(1f)) { Text("시작") }
                                OutlinedButton(onClick = { focusTimerRunning = false; focusRemainingSeconds = 0 }, modifier = Modifier.weight(1f)) { Text("초기화") }
                            }
                            Text("완료 시 집중 기록이 자동으로 저장돼요. 쉬어야 하면 언제든 초기화할 수 있어요.", color = Muted, fontSize = 11.sp)
                        }
                        Text("저장된 기록", color = Paper, fontWeight = FontWeight.Bold)
                        Text(recordText.ifBlank { "아직 기록이 없어요." }, color = Muted)
                    }
                    "플래너" -> {
                        CardBox {
                            Text("오늘", color = Violet, fontWeight = FontWeight.Bold)
                            Text("작게 시작해서 완료 표시하기", color = Paper, fontSize = 18.sp)
                            Text("퀘스트를 완료하면 스스로에게 경험치 +10을 준다고 생각해 봐요.", color = Muted)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Field(task, { task = it }, "할 일 추가", Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = {
                                if (task.isNotBlank()) { tasks = tasks + task.trim(); task = "" }
                            }) { Icon(Icons.Default.Add, contentDescription = "추가") }
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(tasks) { item ->
                                var checked by remember(item) { mutableStateOf(false) }
                                CardBox {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked, {
                                            if (it && !checked) {
                                                affection += 5
                                                prefs.edit().putInt("affection", affection).apply()
                                                val threshold = when (relationshipSpeed) { "빠르게 발전" -> 20; "보통" -> 35; else -> 50 }
                                                relationshipStage = when {
                                                    affection >= threshold * 3 && relationshipType == "연애 가능" -> "연인"
                                                    affection >= threshold * 2 -> "썸"
                                                    affection >= threshold -> "친구"
                                                    else -> "공부 파트너"
                                                }
                                                prefs.edit().putString("relationship_stage", relationshipStage).apply()
                                            }
                                            checked = it
                                        })
                                        Text(item, color = if (checked) Muted else Paper, modifier = Modifier.weight(1f))
                                        Text(if (checked) "+10 XP" else "퀘스트", color = Violet, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Text("AI 연결", color = Violet, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("OpenRouter API 키는 기기 내부에 저장됩니다. 이 방식은 개인 테스트용이며, 앱을 공개 배포할 때는 서버 중계 방식을 사용하세요.", color = Muted, fontSize = 13.sp)
                        Text("API 키", color = Paper, fontWeight = FontWeight.SemiBold)
                        Field(apiKey, { apiKey = it; prefs.edit().putString("api_key", it).apply() }, "sk-or-...", Modifier.fillMaxWidth())
                        Text("모델 ID", color = Paper, fontWeight = FontWeight.SemiBold)
                        Field(model, { model = it; prefs.edit().putString("model", it).apply() }, "openai/gpt-4o-mini", Modifier.fillMaxWidth())
                        Button(onClick = {
                            scope.launch {
                                busy = true
                                status = requestOpenRouter(apiKey, model, listOf(ChatLine("user", "이 연결 테스트에 짧게 응답해 줘.")), characterName, characterPersonality, characterBackground, relationshipStage, relationshipType, relationshipSpeed)
                                busy = false
                            }
                        }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("AI 연결 테스트") }
                        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                        Text(status, color = Muted, fontSize = 12.sp)
                        OutlinedButton(onClick = {
                            apiKey = ""; prefs.edit().remove("api_key").apply()
                            status = "저장된 API 키를 삭제했어요."
                        }, modifier = Modifier.fillMaxWidth()) { Text("API 키 삭제") }
                        Divider(color = Panel)
                        Text("딴짓 감지 설정", color = Violet, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("감지 대상 패키지명 (쉼표로 구분)", color = Paper, fontWeight = FontWeight.SemiBold)
                        Field(targetApps, { targetApps = it; prefs.edit().putString("target_apps", it).apply() }, "com.google.android.youtube,...", Modifier.fillMaxWidth())
                        Text("알림 기준: $usageThreshold분", color = Paper)
                        Slider(value = usageThreshold.toFloat(), onValueChange = { usageThreshold = it.toInt(); prefs.edit().putInt("usage_threshold", usageThreshold).apply() }, valueRange = 5f..90f, steps = 16)
                        Field(nudgeText, { nudgeText = it; prefs.edit().putString("nudge_text", it).apply() }, "잔소리 알림 문구", Modifier.fillMaxWidth())
                        Button(onClick = {
                            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
                            val mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
                            if (mode != AppOpsManager.MODE_ALLOWED) {
                                monitoringStatus = "사용 기록 접근 설정을 열었어요. O.HOME을 허용한 뒤 돌아와 확인해 주세요."
                                context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } else {
                                val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                                val start = System.currentTimeMillis() - 24 * 60 * 60 * 1000L
                                val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, System.currentTimeMillis())
                                val matches = stats.filter { it.packageName in targetApps.split(",").map(String::trim) && it.totalTimeInForeground >= usageThreshold * 60_000L }
                                monitoringStatus = if (matches.isEmpty()) "최근 24시간 기준, 설정한 사용 시간 기준을 넘은 대상 앱이 없어요." else matches.joinToString("\n") { "${it.packageName}: ${it.totalTimeInForeground / 60000}분 사용" } + "\n\n이 화면의 확인은 수동 점검이며, 실시간 백그라운드 감시나 자동 알림은 아직 연결되지 않았어요."
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("사용 기록 권한 확인 / 최근 24시간 사용량 점검") }
                        Text(monitoringStatus, color = Muted, fontSize = 12.sp)
                        Button(onClick = {
                            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
                            val mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
                            if (mode != AppOpsManager.MODE_ALLOWED) {
                                monitoringStatus = "먼저 O.HOME의 사용 기록 접근을 허용해 주세요."
                                context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } else {
                                context.startForegroundService(Intent(context, UsageMonitorService::class.java))
                                monitoringStatus = "백그라운드 감지를 시작했어요. 알림에서 중지할 수 있어요."
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("백그라운드 딴짓 감지 시작") }
                        OutlinedButton(onClick = { context.startService(Intent(context, UsageMonitorService::class.java).setAction(UsageMonitorService.ACTION_STOP)); monitoringStatus = "딴짓 감지를 중지했어요." }, modifier = Modifier.fillMaxWidth()) { Text("딴짓 감지 중지") }
                        OutlinedButton(onClick = {
                            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(intent)
                        }, modifier = Modifier.fillMaxWidth()) { Text("O.HOME 알림 권한 설정") }
                        Divider(color = Panel)
                        Text("백그라운드 감지는 사용 기록 접근 권한이 필요하며, 알림 권한이 꺼져 있으면 잔소리 알림이 표시되지 않을 수 있어요. 기기 제조사별 배터리 최적화 정책에 따라 감지 지속성이 달라질 수 있습니다. 폴더/책별 독립 캐릭터 기억과 클라우드 동기화는 후속 확장 대상입니다.", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(4.dp))
            }
        }
    }
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
private fun FolderCard(name: String, icon: String = "📁", colorName: String = "보라", onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(when (colorName) { "파랑" -> Color(0xFF293F61); "분홍" -> Color(0xFF603B58); "초록" -> Color(0xFF2E5147); else -> Color(0xFF39314F) }, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Text(icon, fontSize = 21.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = Paper, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text("노트 · 할 일 · 자료 · 캐릭터", color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Muted)
        }
    }
}

@Composable
private fun ListRow(title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Circle, contentDescription = null, tint = Violet, modifier = Modifier.size(8.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, color = Paper, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun Field(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier) {
    Box(
        modifier.background(Panel, RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 13.dp)
    ) {
        if (value.isEmpty()) Text(hint, color = Muted, fontSize = 14.sp)
        BasicTextField(
            value = value, onValueChange = onChange,
            modifier = Modifier.fillMaxWidth(),
            textStyle = androidx.compose.ui.text.TextStyle(color = Paper, fontSize = 14.sp),
            singleLine = true
        )
    }
}

private fun calculateStreak(records: String): Int {
    val dates = records.lines().mapNotNull { line ->
        Regex("^\\d{4}-\\d{2}-\\d{2}").find(line)?.value?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
    }.toSet()
    var day = LocalDate.now()
    if (day !in dates) day = day.minusDays(1)
    var count = 0
    while (day in dates) { count++; day = day.minusDays(1) }
    return count
}

private suspend fun requestOpenRouter(apiKey: String, model: String, messages: List<ChatLine>, characterName: String = "공부 파트너", characterPersonality: String = "다정함", characterBackground: String = "", relationshipStage: String = "공부 파트너", relationshipType: String = "연애 가능", relationshipSpeed: String = "보통"): String =
    withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext "연결 오류: 설정에서 OpenRouter API 키를 먼저 입력해 주세요."
        if (model.isBlank()) return@withContext "연결 오류: 모델 ID를 입력해 주세요."
        var connection: HttpURLConnection? = null
        try {
            connection = (URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 45000
                doOutput = true
                setRequestProperty("Authorization", "Bearer $apiKey")
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("HTTP-Referer", "https://ohome.local")
                setRequestProperty("X-Title", "O.HOME")
            }
            val messageArray = JSONArray()
            messageArray.put(JSONObject().put("role", "system").put("content",
                "너는 O.HOME의 AI 캐릭터 '$characterName'이다. 성격: $characterPersonality. 배경: $characterBackground. 현재 관계: $relationshipStage. 관계 설정: $relationshipType. 관계 발전 속도: $relationshipSpeed. 친근하고 자연스러운 한국어로 캐릭터답게 말한다. 공부 질문은 정확하고 단계별로 설명하며, 사용자를 죄책감 주거나 공부를 못했다고 친밀도를 깎는 듯한 말은 하지 않는다. 관계는 대화와 함께 천천히 발전시키고, 연애 가능 설정이 아닐 때는 연인 관계로 진행하지 않는다."))
            messages.takeLast(24).forEach {
                messageArray.put(JSONObject().put("role", it.role).put("content", it.content))
            }
            val body = JSONObject().put("model", model).put("messages", messageArray).toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                val detail = try { JSONObject(response).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                return@withContext "연결 오류: HTTP $code${if (!detail.isNullOrBlank()) " · $detail" else ""}"
            }
            val root = JSONObject(response)
            root.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
                .ifBlank { "응답은 받았지만 내용이 비어 있어요." }
        } catch (e: Exception) {
            "연결 오류: ${e.message ?: "네트워크 또는 API 설정을 확인해 주세요."}"
        } finally {
            connection?.disconnect()
        }
    }
